import React from 'react';
import { View, Text, TouchableOpacity } from 'react-native';
import { patientCardStyles } from './patientCardStyles';

interface Patient {
  caller_name: string;
  patient_name: string;
  patient_age: number;
  patient_sex: string;
  case_history: string;
}

export default function PatientCard({
  patient,
  onPress,
}: {
  patient: Patient;
  onPress?: () => void;
}) {
  return (
    <View style={patientCardStyles.card}>
      <View style={patientCardStyles.headerRow}>
        <Text style={patientCardStyles.patientName}>
          {patient.patient_name}
        </Text>
        <Text style={patientCardStyles.patientInfo}>
          {patient.patient_age} yrs | {patient.patient_sex}
        </Text>
      </View>
      <Text style={patientCardStyles.callerText}>
        <Text style={patientCardStyles.label}>Caller: </Text>
        {patient.caller_name}
      </Text>
      <View style={patientCardStyles.caseHistoryContainer}>
        <Text style={patientCardStyles.caseHistoryLabel}>Case History: </Text>
        <Text
          style={patientCardStyles.caseHistory}
          numberOfLines={5}
          ellipsizeMode="tail"
        >
          {patient.case_history}
        </Text>
      </View>
      <TouchableOpacity
        style={patientCardStyles.assessButton}
        onPress={onPress}
        activeOpacity={0.85}
      >
        <Text style={patientCardStyles.assessButtonText}>Assess Patient</Text>
      </TouchableOpacity>
    </View>
  );
}
