import React, { useState, useRef, useEffect } from "react";
import {
  Modal,
  View,
  Text,
  TouchableOpacity,
  Animated,
  Easing,
  StyleSheet,
  ScrollView,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useVapi, CALL_STATUS } from "@/hooks/useVapi";
import { MessageTypeEnum } from "@/utils/conversation.types";

type AssistantModalProps = {
  visible: boolean;
  onClose: () => void;
  patient?: {
    patient_name: string;
    patient_age?: number | string;
    patient_sex?: string;
    case_summary?: string;
    summary?: string;
    [key: string]: any;
  };
};

export default function AssistantModal({
  visible,
  onClose,
  patient,
}: AssistantModalProps) {
  const { startCall, stop, callStatus, messages, isSpeaking, clearMessages } =
    useVapi();

  const [callerName, setCallerName] = useState<string>("Doctor");

  const pulseAnim = useRef(new Animated.Value(1)).current;
  const scrollViewRef = useRef<ScrollView>(null);

  // Caller (doctor) name from AsyncStorage -> demoUser
  useEffect(() => {
    (async () => {
      try {
        const raw = await AsyncStorage.getItem("demoUser");
        const u = raw ? JSON.parse(raw) : null;
        const name =
          u?.firstName && u?.lastName
            ? `${u.firstName} ${u.lastName}`
            : u?.name || "Doctor";
        setCallerName(name);
      } catch {
        setCallerName("Doctor");
      }
    })();
  }, []);

  // Orb animation
  useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, {
          toValue: 1.18,
          duration: 1100,
          useNativeDriver: true,
          easing: Easing.inOut(Easing.ease),
        }),
        Animated.timing(pulseAnim, {
          toValue: 1,
          duration: 1100,
          useNativeDriver: true,
          easing: Easing.inOut(Easing.ease),
        }),
      ])
    ).start();
  }, [pulseAnim]);

  // Start/Stop call when modal opens/closes; inject patient context into the prompt
  useEffect(() => {
    if (visible && patient?.patient_name) {
      const caseContext = {
        patientName: patient.patient_name,
        age: patient.patient_age,
        sex: patient.patient_sex,
        summary:
          patient.case_summary ??
          patient.case_history ??
          patient.history ??
          patient.summary ??
          patient.case ??
          "",
        callerName,
      };

      clearMessages();
      // startCall from useVapi will fill the system prompt with this context
      startCall({ caseContext });
    } else if (!visible) {
      stop();
    }
    // Re-run if these change:
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    visible,
    patient?.patient_name,
    patient?.patient_age,
    patient?.patient_sex,
    patient?.case_summary,
    patient?.summary,
    callerName,
  ]);

  const handleClose = () => {
    stop();
    onClose();
  };

  let statusText = "";
  if (callStatus === CALL_STATUS.CONNECTING)
    statusText = "Connecting to AI Agent...";
  else if (callStatus === CALL_STATUS.ACTIVE)
    statusText = isSpeaking ? "Assistant is Speaking..." : "Connected";
  else if (callStatus === CALL_STATUS.FINISHED) statusText = "Call Ended";

  // Auto-scroll transcript to bottom
  useEffect(() => {
    scrollViewRef.current?.scrollToEnd({ animated: true });
  }, [messages]);

  return (
    <Modal
      visible={visible}
      transparent
      animationType="fade"
      onRequestClose={handleClose}
    >
      <View style={styles.modalOverlay}>
        <View style={styles.modalContent}>
          <Text style={styles.modalTitle}>Patient Assessment Assistant</Text>
          <Text
            style={{
              color: "#b3b3cc",
              textAlign: "center",
              marginBottom: 8,
              fontSize: 15,
            }}
          >
            Discuss the case history with the AI assistant below to help
            determine the patient's disease.
          </Text>

          <View style={styles.modalBody}>
            <View style={{ alignItems: "center", marginVertical: 10 }}>
              <Animated.View
                style={[
                  styles.orbShadow,
                  {
                    transform: [{ scale: pulseAnim }],
                    shadowOpacity: 0.38,
                    shadowRadius: 38,
                  },
                ]}
              >
                <LinearGradient
                  colors={["#9f7fff", "#6196e8", "#f395e8"]}
                  start={{ x: 0.1, y: 0.1 }}
                  end={{ x: 0.9, y: 0.9 }}
                  style={styles.orb}
                />
              </Animated.View>
            </View>

            <Text style={[styles.modalStatus, { marginTop: 8 }]}>
              {statusText}
            </Text>

            {/* Transcript */}
            <ScrollView
              ref={scrollViewRef}
              style={{
                width: "100%",
                marginTop: 12,
                backgroundColor: "#232345",
                borderRadius: 12,
                padding: 10,
                maxHeight: 220,
              }}
            >
              {messages
                .filter((m) => m.type === MessageTypeEnum.TRANSCRIPT)
                .map((message, idx) => (
                  <View
                    key={idx}
                    style={{
                      marginBottom: 10,
                      alignItems:
                        message.role === "user" ? "flex-end" : "flex-start",
                    }}
                  >
                    <View
                      style={{
                        maxWidth: "80%",
                        borderRadius: 12,
                        paddingVertical: 6,
                        paddingHorizontal: 12,
                        backgroundColor:
                          message.role === "user" ? "#fdba74" : "#e5e7eb",
                      }}
                    >
                      <Text style={{ fontSize: 14, color: "#1f2937" }}>
                        {message.transcript}
                      </Text>
                    </View>
                  </View>
                ))}
            </ScrollView>
          </View>

          <View style={styles.modalButtons}>
            {callStatus === CALL_STATUS.CONNECTING ||
            callStatus === CALL_STATUS.ACTIVE ? (
              <TouchableOpacity
                onPress={handleClose}
                style={[
                  styles.button,
                  { backgroundColor: "#f66", minWidth: 130 },
                ]}
              >
                <Text style={[styles.buttonText, { color: "#fff" }]}>
                  End Call
                </Text>
              </TouchableOpacity>
            ) : (
              <TouchableOpacity
                onPress={handleClose}
                style={[
                  styles.button,
                  { backgroundColor: "#6196e8", minWidth: 130 },
                ]}
              >
                <Text style={[styles.buttonText, { color: "#fff" }]}>
                  Close
                </Text>
              </TouchableOpacity>
            )}
          </View>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.18)",
    justifyContent: "center",
    alignItems: "center",
  },
  modalContent: {
    width: "90%",
    height: "90%",
    backgroundColor: "#232333",
    borderRadius: 22,
    paddingHorizontal: 28,
    paddingTop: 28,
    paddingBottom: 22,
    alignItems: "center",
    justifyContent: "space-between",
    elevation: 10,
    maxWidth: 430,
    minWidth: 290,
    minHeight: 360,
  },
  modalTitle: {
    fontWeight: "bold",
    fontSize: 22,
    color: "#fff",
    marginBottom: 12,
    textAlign: "center",
    letterSpacing: 0.2,
  },
  modalBody: {
    flex: 1,
    width: "100%",
    alignItems: "center",
    justifyContent: "center",
  },
  modalStatus: {
    fontSize: 17,
    fontWeight: "600",
    color: "#6196e8",
    marginTop: 24,
    textAlign: "center",
    marginBottom: 2,
  },
  modalButtons: {
    width: "100%",
    alignItems: "center",
    marginBottom: 6,
  },
  button: {
    backgroundColor: "#6196e8",
    paddingVertical: 10,
    borderRadius: 8,
    alignItems: "center",
    marginTop: 6,
  },
  buttonText: { color: "#fff", fontWeight: "bold", fontSize: 16 },
  orbShadow: {
    shadowColor: "#9e86ec",
    shadowOpacity: 0.32,
    shadowRadius: 38,
    shadowOffset: { width: 0, height: 50 },
    backgroundColor: "rgba(241,236,255,0.80)",
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 60,
    width: 120,
    height: 120,
    elevation: 20,
    borderWidth: 1,
    borderColor: "rgba(170,142,255,0.18)",
  },
  orb: {
    width: 100,
    height: 100,
    borderRadius: 50,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.27)",
    overflow: "hidden",
  },
  dot: {
    width: 7,
    height: 25,
    backgroundColor: "#6196e8",
    marginHorizontal: 5,
    opacity: 0.8,
    marginTop: 2,
  },
});
