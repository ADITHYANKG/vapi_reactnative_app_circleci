export const patients =[
    {
      "caller_name": "James Rodriguez",
      "patient_name": "Jone Jones",
      "patient_age": 56,
      "patient_sex": "male",
      "case_history": "presents with small bloody hematochezia. No hematemesis, denies melena. Patient reports symptoms for >2 Days. Patient denies syncope, denies unstable CAD, denies COPD, denies CRF, denies risk for stress ulcer, denies cirrhosis, reports ASANSAID use, denies PPI use. Prior history of No GI bleed. BP is 126/64, HR 88 without orthostasis. NG lavage was bilious, and rectal exam showed small blood. Lab showed a hematocrit of 41, hematocrit drop from baseline of about 2, Platelets 142, Creatinine 1.1, BUN 12, INR 0.9.",
      "date_created": "2023-05-12T08:23:45Z",
      "date_modified": "2023-05-12T14:35:21Z"
    },
    {
      "caller_name": "John Smith",
      "patient_name": "Mary Johnson",
      "patient_age": 62,
      "patient_sex": "female",
      "case_history": "presents with small bloody hematochezia. No hematemesis, denies melena. Patient reports symptoms for >2 Days. Patient denies syncope, denies unstable CAD, denies COPD, denies CRF, denies risk for stress ulcer, denies cirrhosis, denies ASANSAID use, reports PPI use. Prior history of No GI bleed. BP is 114/74, HR 92 without orthostasis. NG lavage was bilious, and rectal exam showed small blood. Lab showed a hematocrit of 39, hematocrit drop from baseline of about 3, Platelets 126, Creatinine 0.9, BUN 14, INR 0.8.",
      "date_created": "2023-06-18T11:45:32Z",
      "date_modified": "2023-06-18T16:22:10Z"
    },
    {
      "caller_name": "Lily Brown",
      "patient_name": "David Smith",
      "patient_age": 44,
      "patient_sex": "male",
      "case_history": "presents with No hematochezia, small bloody hematemesis, reports melena. Patient reports symptoms for 1-2 Days. Patient reports syncope, denies unstable CAD, denies COPD, denies CRF, denies risk for stress ulcer, denies cirrhosis, denies ASANSAID use, denies PPI use. Prior history of No GI bleed. BP is 96/60, HR 104 with orthostasis. NG lavage was coffee grounds, and rectal exam showed melanotic stool. Lab showed a hematocrit of 36, hematocrit drop from baseline of about 6, Platelets 146, Creatinine 0.9, BUN 24, INR 1.1.",
      "date_created": "2023-07-03T09:12:56Z",
      "date_modified": "2023-07-03T09:12:56Z"
    },
    {
      "caller_name": "Sophia Walker",
      "patient_name": "Emma Williams",
      "patient_age": 53,
      "patient_sex": "female",
      "case_history": "presents with acute abdominal pain and vomiting. No hematochezia, denies melena. Patient reports symptoms for 1 day. BP is 110/70, HR 96 without orthostasis. NG lavage was clear. Lab results show hematocrit of 43, Platelets 150, Creatinine 1.0, BUN 18, INR 1.0.",
      "date_created": "2023-04-22T14:30:18Z",
      "date_modified": "2023-04-22T18:45:33Z"
    },
    {
      "caller_name": "Michael Green",
      "patient_name": "Sarah Lee",
      "patient_age": 65,
      "patient_sex": "female",
      "case_history": "presents with bright red hematochezia. No melena, denies vomiting. Patient reports symptoms for 2 days. BP is 120/80, HR 78 without orthostasis. NG lavage was clear, rectal exam showed fresh blood. Lab results show hematocrit of 40, Platelets 132, Creatinine 1.2, BUN 14, INR 1.0.",
      "date_created": "2023-08-05T07:15:42Z",
      "date_modified": "2023-08-05T12:20:15Z"
    },
    {
      "caller_name": "Oliver White",
      "patient_name": "Brian Clark",
      "patient_age": 36,
      "patient_sex": "male",
      "case_history": "presents with small bloody stools, denies hematemesis. Patient reports symptoms for 3 days. BP is 126/78, HR 88 without orthostasis. NG lavage was clear, rectal exam showed small amount of blood. Lab results show hematocrit of 45, Platelets 160, Creatinine 1.1, BUN 12, INR 1.0.",
      "date_created": "2023-09-10T10:25:30Z",
      "date_modified": "2023-09-10T15:40:22Z"
    },
    {
      "caller_name": "Grace Martin",
      "patient_name": "Jessica Turner",
      "patient_age": 41,
      "patient_sex": "female",
      "case_history": "presents with no hematochezia, reports small amounts of hematemesis. Patient reports symptoms for 1 day. BP is 110/65, HR 102 with orthostasis. NG lavage was coffee grounds. Lab results show hematocrit of 39, Platelets 142, Creatinine 0.9, BUN 20, INR 1.2.",
      "date_created": "2023-03-15T13:40:11Z",
      "date_modified": "2023-03-15T13:40:11Z"
    },
    {
      "caller_name": "Daniel Brown",
      "patient_name": "George Harris",
      "patient_age": 50,
      "patient_sex": "male",
      "case_history": "presents with melena and nausea. No hematochezia. Patient reports symptoms for 2 days. BP is 128/75, HR 80 without orthostasis. NG lavage was coffee grounds, rectal exam showed dark stools. Lab results show hematocrit of 42, Platelets 138, Creatinine 1.0, BUN 22, INR 1.0.",
      "date_created": "2023-10-08T16:50:05Z",
      "date_modified": "2023-10-09T09:15:33Z"
    },
    {
      "caller_name": "Isabella Miller",
      "patient_name": "Michael Young",
      "patient_age": 72,
      "patient_sex": "male",
      "case_history": "presents with abdominal cramping and vomiting. Denies hematochezia. Patient reports symptoms for 3 days. BP is 130/85, HR 88 without orthostasis. NG lavage was clear. Lab results show hematocrit of 41, Platelets 145, Creatinine 1.1, BUN 14, INR 0.9.",
      "date_created": "2023-02-28T08:10:45Z",
      "date_modified": "2023-02-28T11:25:18Z"
    },
    {
      "caller_name": "Rachel Thompson",
      "patient_name": "Lisa Davis",
      "patient_age": 29,
      "patient_sex": "female",
      "case_history": "presents with moderate hematochezia and cramping. No hematemesis, denies melena. Patient reports symptoms for 1-2 days. Patient denies syncope, denies unstable CAD, denies COPD, denies CRF, denies risk for stress ulcer, denies cirrhosis, denies ASANSAID use, denies PPI use. Prior history of No GI bleed. BP is 118/72, HR 94 without orthostasis. NG lavage was clear, and rectal exam showed moderate blood. Lab showed a hematocrit of 38, hematocrit drop from baseline of about 4, Platelets 156, Creatinine 0.8, BUN 16, INR 0.9.",
      "date_created": "2023-11-14T09:35:27Z",
      "date_modified": "2023-11-14T14:50:39Z"
    },
    {
      "caller_name": "Thomas Anderson",
      "patient_name": "Robert Wilson",
      "patient_age": 67,
      "patient_sex": "male",
      "case_history": "presents with hematemesis and dizziness. No hematochezia, reports melena. Patient reports symptoms for <1 day. Patient reports syncope, denies unstable CAD, denies COPD, denies CRF, reports risk for stress ulcer, denies cirrhosis, reports ASANSAID use, denies PPI use. Prior history of previous GI bleed 5 years ago. BP is 100/58, HR 110 with orthostasis. NG lavage was coffee grounds with red blood, and rectal exam showed melanotic stool. Lab showed a hematocrit of 32, hematocrit drop from baseline of about 8, Platelets 134, Creatinine 1.3, BUN 28, INR 1.4.",
      "date_created": "2023-01-20T12:15:33Z",
      "date_modified": "2023-01-20T12:15:33Z"
    },
    {
      "caller_name": "Amy Garcia",
      "patient_name": "Jennifer Martinez",
      "patient_age": 48,
      "patient_sex": "female",
      "case_history": "presents with upper abdominal pain and nausea. No hematochezia, no hematemesis, denies melena. Patient reports symptoms for 4 hours. Patient denies syncope, denies unstable CAD, denies COPD, denies CRF, denies risk for stress ulcer, denies cirrhosis, reports ASANSAID use, reports PPI use. Prior history of No GI bleed. BP is 124/78, HR 86 without orthostasis. NG lavage was clear. Lab showed a hematocrit of 44, no hematocrit drop from baseline, Platelets 148, Creatinine 0.9, BUN 15, INR 1.0.",
      "date_created": "2023-12-05T10:40:19Z",
      "date_modified": "2023-12-05T15:55:42Z"
    },
    {
      "caller_name": "Kevin Rodriguez",
      "patient_name": "Christopher Taylor",
      "patient_age": 58,
      "patient_sex": "male",
      "case_history": "presents with large volume hematochezia. No hematemesis, denies melena. Patient reports symptoms for 6 hours. Patient reports syncope, denies unstable CAD, denies COPD, denies CRF, denies risk for stress ulcer, denies cirrhosis, denies ASANSAID use, denies PPI use. Prior history of No GI bleed. BP is 108/62, HR 106 with orthostasis. NG lavage was bilious, and rectal exam showed large volume of fresh blood. Lab showed a hematocrit of 34, hematocrit drop from baseline of about 7, Platelets 128, Creatinine 1.0, BUN 18, INR 1.1.",
      "date_created": "2023-07-22T14:20:08Z",
      "date_modified": "2023-07-22T19:30:25Z"
    },
    {
      "caller_name": "Laura Mitchell",
      "patient_name": "Amanda Moore",
      "patient_age": 39,
      "patient_sex": "female",
      "case_history": "presents with coffee ground vomiting and epigastric pain. No hematochezia, reports melena. Patient reports symptoms for 1 day. Patient denies syncope, denies unstable CAD, denies COPD, denies CRF, reports risk for stress ulcer, denies cirrhosis, reports ASANSAID use, denies PPI use. Prior history of peptic ulcer disease. BP is 116/68, HR 98 without orthostasis. NG lavage was coffee grounds, and rectal exam showed melanotic stool. Lab showed a hematocrit of 37, hematocrit drop from baseline of about 5, Platelets 140, Creatinine 0.8, BUN 22, INR 1.0.",
      "date_created": "2023-08-30T11:05:47Z",
      "date_modified": "2023-08-30T11:05:47Z"
    },
    {
      "caller_name": "Steven Clark",
      "patient_name": "Mark Jackson",
      "patient_age": 74,
      "patient_sex": "male",
      "case_history": "presents with weakness and fatigue. Small hematochezia noted, no hematemesis, denies melena. Patient reports symptoms for 5 days. Patient denies syncope, reports unstable CAD, reports COPD, denies CRF, denies risk for stress ulcer, denies cirrhosis, reports ASANSAID use, reports PPI use. Prior history of previous GI bleed 2 years ago. BP is 132/78, HR 82 without orthostasis. NG lavage was bilious, and rectal exam showed trace blood. Lab showed a hematocrit of 35, hematocrit drop from baseline of about 6, Platelets 122, Creatinine 1.4, BUN 26, INR 2.1.",
      "date_created": "2023-05-17T09:25:14Z",
      "date_modified": "2023-05-17T14:40:36Z"
    },
    {
      "caller_name": "Natalie Lewis",
      "patient_name": "Karen White",
      "patient_age": 52,
      "patient_sex": "female",
      "case_history": "presents with bright red blood per rectum and abdominal cramping. No hematemesis, denies melena. Patient reports symptoms for 8 hours. Patient denies syncope, denies unstable CAD, denies COPD, denies CRF, denies risk for stress ulcer, denies cirrhosis, denies ASANSAID use, denies PPI use. Prior history of hemorrhoids. BP is 122/74, HR 90 without orthostasis. NG lavage was clear, and rectal exam showed fresh red blood. Lab showed a hematocrit of 40, hematocrit drop from baseline of about 3, Platelets 154, Creatinine 0.9, BUN 14, INR 0.9.",
      "date_created": "2023-06-29T13:15:22Z",
      "date_modified": "2023-06-29T18:30:44Z"
    },
    {
      "caller_name": "Patricia Hill",
      "patient_name": "Daniel Thompson",
      "patient_age": 33,
      "patient_sex": "male",
      "case_history": "presents with tarry stools and lightheadedness. No hematochezia, no hematemesis, reports melena. Patient reports symptoms for 2 days. Patient reports syncope, denies unstable CAD, denies COPD, denies CRF, denies risk for stress ulcer, denies cirrhosis, reports ASANSAID use, denies PPI use. Prior history of No GI bleed. BP is 104/66, HR 108 with orthostasis. NG lavage was coffee grounds, and rectal exam showed melanotic stool. Lab showed a hematocrit of 33, hematocrit drop from baseline of about 7, Platelets 136, Creatinine 1.0, BUN 26, INR 1.0.",
      "date_created": "2023-09-25T15:45:19Z",
      "date_modified": "2023-09-25T15:45:19Z"
    },
    {
      "caller_name": "Marcus Johnson",
      "patient_name": "Sandra Rodriguez",
      "patient_age": 61,
      "patient_sex": "female",
      "case_history": "presents with chest pain and shortness of breath. No hematochezia, no hematemesis, denies melena. Patient reports symptoms for 2 hours. Patient denies syncope, reports unstable CAD, denies COPD, denies CRF, denies risk for stress ulcer, denies cirrhosis, denies ASANSAID use, reports PPI use. Prior history of No GI bleed. BP is 142/88, HR 94 without orthostasis. NG lavage was clear. Lab showed a hematocrit of 42, no hematocrit drop from baseline, Platelets 162, Creatinine 1.1, BUN 16, INR 1.0.",
      "date_created": "2023-04-10T10:30:28Z",
      "date_modified": "2023-04-10T15:45:37Z"
    },
    {
      "caller_name": "Christina Wong",
      "patient_name": "Paul Anderson",
      "patient_age": 45,
      "patient_sex": "male",
      "case_history": "presents with massive hematemesis and altered mental status. No hematochezia, reports melena. Patient reports symptoms for 1 hour. Patient reports syncope, denies unstable CAD, denies COPD, denies CRF, denies risk for stress ulcer, reports cirrhosis, denies ASANSAID use, denies PPI use. Prior history of esophageal varices. BP is 88/52, HR 124 with orthostasis. NG lavage was bright red blood, and rectal exam showed melanotic stool. Lab showed a hematocrit of 28, hematocrit drop from baseline of about 12, Platelets 98, Creatinine 1.2, BUN 32, INR 2.8.",
      "date_created": "2023-11-08T08:15:42Z",
      "date_modified": "2023-11-08T13:30:55Z"
    },
    {
      "caller_name": "Benjamin Cooper",
      "patient_name": "Michelle Garcia",
      "patient_age": 37,
      "patient_sex": "female",
      "case_history": "presents with intermittent hematochezia and constipation. No hematemesis, denies melena. Patient reports symptoms for 1 week. Patient denies syncope, denies unstable CAD, denies COPD, denies CRF, denies risk for stress ulcer, denies cirrhosis, denies ASANSAID use, denies PPI use. Prior history of No GI bleed. BP is 118/76, HR 84 without orthostasis. NG lavage was clear, and rectal exam showed small amount of blood. Lab showed a hematocrit of 39, hematocrit drop from baseline of about 2, Platelets 158, Creatinine 0.8, BUN 12, INR 0.9.",
      "date_created": "2023-03-05T12:40:15Z",
      "date_modified": "2023-03-05T12:40:15Z"
    },
    {
      "caller_name": "Victoria Adams",
      "patient_name": "James Wilson",
      "patient_age": 68,
      "patient_sex": "male",
      "case_history": "presents with nausea and vomiting. No hematochezia, small hematemesis, denies melena. Patient reports symptoms for 6 hours. Patient denies syncope, denies unstable CAD, denies COPD, reports CRF, reports risk for stress ulcer, denies cirrhosis, reports ASANSAID use, reports PPI use. Prior history of chronic kidney disease. BP is 156/92, HR 76 without orthostasis. NG lavage was coffee grounds, and rectal exam was normal. Lab showed a hematocrit of 36, hematocrit drop from baseline of about 4, Platelets 124, Creatinine 2.8, BUN 68, INR 1.3.",
      "date_created": "2023-10-15T14:25:33Z",
      "date_modified": "2023-10-15T19:40:46Z"
    },
    {
      "caller_name": "Ryan Murphy",
      "patient_name": "Angela Davis",
      "patient_age": 42,
      "patient_sex": "female",
      "case_history": "presents with severe abdominal pain and bloody diarrhea. Reports hematochezia, no hematemesis, denies melena. Patient reports symptoms for 3 days. Patient denies syncope, denies unstable CAD, denies COPD, denies CRF, denies risk for stress ulcer, denies cirrhosis, denies ASANSAID use, denies PPI use. Prior history of inflammatory bowel disease. BP is 112/68, HR 102 without orthostasis. NG lavage was clear, and rectal exam showed blood and mucus. Lab showed a hematocrit of 35, hematocrit drop from baseline of about 5, Platelets 428, Creatinine 0.9, BUN 20, INR 1.1.",
      "date_created": "2023-02-12T11:35:27Z",
      "date_modified": "2023-02-12T16:50:38Z"
    },
    {
      "caller_name": "Samantha Lee",
      "patient_name": "Kevin Martinez",
      "patient_age": 55,
      "patient_sex": "male",
      "case_history": "presents with chest discomfort and dyspepsia. No hematochezia, no hematemesis, denies melena. Patient reports symptoms for 1 day. Patient denies syncope, denies unstable CAD, denies COPD, denies CRF, denies risk for stress ulcer, denies cirrhosis, reports ASANSAID use, reports PPI use. Prior history of GERD. BP is 134/82, HR 88 without orthostasis. NG lavage was clear. Lab showed a hematocrit of 43, no hematocrit drop from baseline, Platelets 152, Creatinine 1.0, BUN 18, INR 1.0.",
      "date_created": "2023-07-08T09:45:19Z",
      "date_modified": "2023-07-08T09:45:19Z"
    },
    {
      "caller_name": "Jonathan Taylor",
      "patient_name": "Rebecca Johnson",
      "patient_age": 28,
      "patient_sex": "female",
      "case_history": "presents with bright red blood per rectum during pregnancy. Reports hematochezia, no hematemesis, denies melena. Patient reports symptoms for 12 hours. Patient denies syncope, denies unstable CAD, denies COPD, denies CRF, denies risk for stress ulcer, denies cirrhosis, denies ASANSAID use, denies PPI use. Prior history of hemorrhoids in pregnancy. BP is 108/64, HR 96 without orthostasis. NG lavage was clear, and rectal exam showed external hemorrhoids with bleeding. Lab showed a hematocrit of 36, hematocrit drop from baseline of about 3, Platelets 168, Creatinine 0.7, BUN 8, INR 0.9.",
      "date_created": "2023-12-12T13:55:24Z",
      "date_modified": "2023-12-12T19:10:35Z"
    },
    {
      "caller_name": "Nicole Brown",
      "patient_name": "Timothy Clark",
      "patient_age": 63,
      "patient_sex": "male",
      "case_history": "presents with fatigue and dark stools. No hematochezia, no hematemesis, reports melena. Patient reports symptoms for 4 days. Patient denies syncope, denies unstable CAD, denies COPD, denies CRF, denies risk for stress ulcer, denies cirrhosis, reports ASANSAID use, reports PPI use. Prior history of peptic ulcer disease. BP is 128/74, HR 92 without orthostasis. NG lavage was coffee grounds, and rectal exam showed melanotic stool. Lab showed a hematocrit of 34, hematocrit drop from baseline of about 6, Platelets 144, Creatinine 1.1, BUN 24, INR 1.0.",
      "date_created": "2023-01-25T15:20:11Z",
      "date_modified": "2023-01-25T20:35:22Z"
    },
    {
      "caller_name": "Andrew White",
      "patient_name": "Lisa Thompson",
      "patient_age": 51,
      "patient_sex": "female",
      "case_history": "presents with vomiting and epigastric pain. No hematochezia, reports hematemesis, denies melena. Patient reports symptoms for 8 hours. Patient denies syncope, denies unstable CAD, denies COPD, denies CRF, denies risk for stress ulcer, denies cirrhosis, reports ASANSAID use, denies PPI use. Prior history of No GI bleed. BP is 114/70, HR 100 without orthostasis. NG lavage was bright red blood, and rectal exam was normal. Lab showed a hematocrit of 38, hematocrit drop from baseline of about 4, Platelets 146, Creatinine 0.9, BUN 18, INR 1.0.",
      "date_created": "2023-08-19T10:10:36Z",
      "date_modified": "2023-08-19T10:10:36Z"
    },
    {
      "caller_name": "Stephanie Miller",
      "patient_name": "Charles Davis",
      "patient_age": 70,
      "patient_sex": "male",
      "case_history": "presents with weakness and dizziness. Small hematochezia, no hematemesis, denies melena. Patient reports symptoms for 1 week. Patient denies syncope, reports unstable CAD, reports COPD, denies CRF, denies risk for stress ulcer, denies cirrhosis, reports ASANSAID use, reports PPI use. Prior history of colonic polyps. BP is 136/80, HR 86 without orthostasis. NG lavage was clear, and rectal exam showed trace blood. Lab showed a hematocrit of 32, hematocrit drop from baseline of about 8, Platelets 118, Creatinine 1.3, BUN 28, INR 2.4.",
      "date_created": "2023-05-30T14:35:42Z",
      "date_modified": "2023-05-30T19:50:53Z"
    },
    {
      "caller_name": "Jennifer Wilson",
      "patient_name": "Steven Rodriguez",
      "patient_age": 47,
      "patient_sex": "male",
      "case_history": "presents with acute onset of bloody vomiting. No hematochezia, reports hematemesis, denies melena. Patient reports symptoms for 2 hours. Patient reports syncope, denies unstable CAD, denies COPD, denies CRF, denies risk for stress ulcer, reports cirrhosis, denies ASANSAID use, denies PPI use. Prior history of portal hypertension. BP is 94/58, HR 116 with orthostasis. NG lavage was bright red blood, and rectal exam was normal. Lab showed a hematocrit of 30, hematocrit drop from baseline of about 9, Platelets 86, Creatinine 1.0, BUN 30, INR 3.2.",
      "date_created": "2023-09-05T12:25:19Z",
      "date_modified": "2023-09-05T17:40:30Z"
    },
    {
      "caller_name": "David Anderson",
      "patient_name": "Carol Martinez",
      "patient_age": 59,
      "patient_sex": "female",
      "case_history": "presents with abdominal cramping and loose stools. Reports hematochezia, no hematemesis, denies melena. Patient reports symptoms for 2 days. Patient denies syncope, denies unstable CAD, denies COPD, denies CRF, denies risk for stress ulcer, denies cirrhosis, denies ASANSAID use, denies PPI use. Prior history of diverticulosis. BP is 124/76, HR 88 without orthostasis. NG lavage was clear, and rectal exam showed blood mixed with stool. Lab showed a hematocrit of 37, hematocrit drop from baseline of about 4, Platelets 156, Creatinine 1.0, BUN 16, INR 0.9.",
      "date_created": "2023-06-14T08:15:33Z",
      "date_modified": "2023-06-14T08:15:33Z"
    },
    {
      "caller_name": "Maria Garcia",
      "patient_name": "Richard Johnson",
      "patient_age": 41,
      "patient_sex": "male",
      "case_history": "presents with upper abdominal burning and nausea. No hematochezia, no hematemesis, denies melena. Patient reports symptoms for 3 days. Patient denies syncope, denies unstable CAD, denies COPD, denies CRF, denies risk for stress ulcer, denies cirrhosis, reports ASANSAID use, denies PPI use. Prior history of gastritis. BP is 122/78, HR 82 without orthostasis. NG lavage was clear. Lab showed a hematocrit of 44, no hematocrit drop from baseline, Platelets 148, Creatinine 0.9, BUN 14, INR 1.0.",
      "date_created": "2023-11-22T10:40:25Z",
      "date_modified": "2023-11-22T15:55:36Z"
    },
    {
      "caller_name": "Robert Taylor",
      "patient_name": "Susan White",
      "patient_age": 66,
      "patient_sex": "female",
      "case_history": "presents with large volume bloody stools. Reports hematochezia, no hematemesis, denies melena. Patient reports symptoms for 4 hours. Patient reports syncope, denies unstable CAD, denies COPD, denies CRF, denies risk for stress ulcer, denies cirrhosis, denies ASANSAID use, denies PPI use. Prior history of colonic angiodysplasia. BP is 102/64, HR 108 with orthostasis. NG lavage was clear, and rectal exam showed large volume fresh blood. Lab showed a hematocrit of 31, hematocrit drop from baseline of about 9, Platelets 132, Creatinine 1.1, BUN 20, INR 1.0.",
      "date_created": "2023-04-05T14:50:17Z",
      "date_modified": "2023-04-05T20:05:28Z"
    },
    {
      "caller_name": "Elizabeth Clark",
      "patient_name": "Matthew Brown",
      "patient_age": 54,
      "patient_sex": "male",
      "case_history": "presents with coffee ground emesis and weakness. No hematochezia, reports hematemesis, reports melena. Patient reports symptoms for 1 day. Patient denies syncope, denies unstable CAD, denies COPD, denies CRF, reports risk for stress ulcer, denies cirrhosis, reports ASANSAID use, reports PPI use. Prior history of duodenal ulcer. BP is 118/72, HR 98 without orthostasis. NG lavage was coffee grounds, and rectal exam showed melanotic stool. Lab showed a hematocrit of 35, hematocrit drop from baseline of about 5, Platelets 138, Creatinine 1.0, BUN 22, INR 1.1.",
      "date_created": "2023-10-03T11:30:42Z",
      "date_modified": "2023-10-03T11:30:42Z"
    },
    {
      "caller_name": "Michelle Davis",
      "patient_name": "Joseph Wilson",
      "patient_age": 49,
      "patient_sex": "male",
      "case_history": "presents with rectal bleeding and tenesmus. Reports hematochezia, no hematemesis, denies melena. Patient reports symptoms for 5 days. Patient denies syncope, denies unstable CAD, denies COPD, denies CRF, denies risk for stress ulcer, denies cirrhosis, denies ASANSAID use, denies PPI use. Prior history of ulcerative colitis. BP is 116/74, HR 92 without orthostasis. NG lavage was clear, and rectal exam showed blood and mucus. Lab showed a hematocrit of 36, hematocrit drop from baseline of about 4, Platelets 384, Creatinine 0.9, BUN 18, INR 1.0.",
      "date_created": "2023-03-28T13:20:15Z",
      "date_modified": "2023-03-28T18:35:26Z"
    },
    {
      "caller_name": "Christopher Miller",
      "patient_name": "Patricia Anderson",
      "patient_age": 73,
      "patient_sex": "female",
      "case_history": "presents with altered mental status and weakness. Small hematochezia, no hematemesis, denies melena. Patient reports symptoms for 2 days. Patient denies syncope, reports unstable CAD, reports COPD, reports CRF, denies risk for stress ulcer, denies cirrhosis, reports ASANSAID use, reports PPI use. Prior history of multiple medical comorbidities. BP is 146/88, HR 78 without orthostasis. NG lavage was clear, and rectal exam showed small amount of blood. Lab showed a hematocrit of 28, hematocrit drop from baseline of about 10, Platelets 108, Creatinine 2.2, BUN 58, INR 2.6.",
      "date_created": "2023-07-15T15:45:29Z",
      "date_modified": "2023-07-15T21:00:40Z"
    },
    {
      "caller_name": "Amanda Rodriguez",
      "patient_name": "William Garcia",
      "patient_age": 38,
      "patient_sex": "male",
      "case_history": "presents with epigastric pain radiating to back. No hematochezia, no hematemesis, denies melena. Patient reports symptoms for 6 hours. Patient denies syncope, denies unstable CAD, denies COPD, denies CRF, denies risk for stress ulcer, denies cirrhosis, denies ASANSAID use, denies PPI use. Prior history of alcohol use disorder. BP is 128/84, HR 94 without orthostasis. NG lavage was clear. Lab showed a hematocrit of 42, no hematocrit drop from baseline, Platelets 156, Creatinine 1.0, BUN 16, INR 1.0.",
      "date_created": "2023-12-18T09:55:33Z",
      "date_modified": "2023-12-18T09:55:33Z"
    }
  ]