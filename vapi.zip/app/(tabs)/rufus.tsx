//C:\vapi-npm-15-Home-page-content-added-from-adithyan\app\(tabs)\rufus.tsx
import { Text, View } from 'react-native';
// This is just a placeholder in the tab bar, the actual Rufus page is in the components folder
const Page = () => {
  return (
    <View>
      <Text>Page</Text>
    </View>
  );
};
export default Page;